package com.lotte.econ.keyword.api.service;

import com.lotte.econ.keyword.entity.Sample;
import com.lotte.econ.keyword.service.SampleService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApiSampleService {

    @Autowired
    private SampleService sampleService;

    public List<Sample> getSamples() {
        return sampleService.getSamples();
    }

    public Sample getSample(Long sampleId) {
        return sampleService.getSample(sampleId);
    }

    public Sample setSample(Sample command) {
        return sampleService.setSample(command);
    }

    public Sample putSample(Long sampleId, Sample command) {
        Sample sample = sampleService.getSample(sampleId);

        return sampleService.putSample(sampleId, sample);
    }

    public void delSample(Long sampleId) {
        sampleService.delSample(sampleId);
    }

}